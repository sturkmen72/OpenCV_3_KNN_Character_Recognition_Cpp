The video pretty much explains it all:
https://www.youtube.com/watch?v=CK0OCeCN9zg
